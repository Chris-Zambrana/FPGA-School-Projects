# Starter code can be found here

1. bin_to_leds module (needs to be completed)
2. invert7 module (needs to be completed)
3. seven_seg_out module (complete)
4. tb_lab1 test bench module (needs to be completed)
